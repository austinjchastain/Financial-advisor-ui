import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Calendar, DollarSign, Star } from "lucide-react"

export default function RetirementPlanning() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Retirement Planning</h2>
          <p className="text-muted-foreground">Long-term financial security</p>
        </div>
        <div className="flex items-center gap-2 rounded-lg bg-rose-50 px-3 py-1 text-rose-700">
          <AlertTriangle className="h-4 w-4" />
          <span className="text-sm font-medium">Needs Attention</span>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
          <CardHeader>
            <CardTitle>Retirement Overview</CardTitle>
            <CardDescription>Your progress toward retirement goals</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg border border-slate-200 bg-white p-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <h4 className="text-sm font-medium">Target Age</h4>
                </div>
                <div className="mt-2 text-2xl font-bold">65</div>
              </div>

              <div className="rounded-lg border border-slate-200 bg-white p-4">
                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <h4 className="text-sm font-medium">Readiness</h4>
                </div>
                <div className="mt-2 text-2xl font-bold text-rose-600">3/10</div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Current Savings</span>
                <span className="font-medium">$60,000</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Target Needed</span>
                <span className="font-medium">$1.2M</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Progress to Goal</span>
                <span className="font-medium text-rose-600">5% of target</span>
              </div>
              <Progress value={5} className="h-1.5 bg-slate-100" indicatorClassName="bg-rose-500" />
            </div>

            <div className="rounded-lg bg-rose-50 p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="mt-0.5 h-5 w-5 text-rose-600" />
                <div>
                  <p className="font-medium text-rose-800">Significant Gap</p>
                  <p className="text-sm text-rose-700">
                    You're significantly behind on retirement savings. Consider increasing contributions dramatically,
                    delaying retirement, or adjusting your lifestyle expectations.
                  </p>
                </div>
              </div>
            </div>

            <Button className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
              Boost Retirement Plan
            </Button>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
          <CardHeader>
            <CardTitle>Retirement Lifestyle</CardTitle>
            <CardDescription>Projected living standards</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="rounded-lg border border-slate-200 bg-white p-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <h4 className="text-sm font-medium">Annual Spending</h4>
              </div>
              <div className="mt-2 text-2xl font-bold">$48,000</div>
              <p className="text-xs text-muted-foreground">In today's dollars, adjusted for inflation</p>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Retirement Income Sources</h4>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-violet-500"></div>
                    <span className="text-sm">Social Security</span>
                  </div>
                  <span className="text-sm font-medium">$24,000/year</span>
                </div>
                <Progress value={50} className="h-1.5 bg-slate-100" indicatorClassName="bg-violet-500" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-amber-500"></div>
                    <span className="text-sm">401(k) & IRA</span>
                  </div>
                  <span className="text-sm font-medium">$18,000/year</span>
                </div>
                <Progress value={37.5} className="h-1.5 bg-slate-100" indicatorClassName="bg-amber-500" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-slate-400"></div>
                    <span className="text-sm">Other Savings</span>
                  </div>
                  <span className="text-sm font-medium">$6,000/year</span>
                </div>
                <Progress value={12.5} className="h-1.5 bg-slate-100" indicatorClassName="bg-slate-400" />
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Key Action Items</h4>

              <div className="space-y-2">
                <div className="flex items-start gap-3 rounded-lg p-2 transition-colors hover:bg-slate-50">
                  <div className="mt-0.5 rounded-full bg-rose-100 p-1">
                    <span className="text-xs font-bold text-rose-700">1</span>
                  </div>
                  <p className="text-sm">Increase 401(k) contribution to at least 15% of income</p>
                </div>

                <div className="flex items-start gap-3 rounded-lg p-2 transition-colors hover:bg-slate-50">
                  <div className="mt-0.5 rounded-full bg-rose-100 p-1">
                    <span className="text-xs font-bold text-rose-700">2</span>
                  </div>
                  <p className="text-sm">Consider working until age 67 to maximize Social Security</p>
                </div>

                <div className="flex items-start gap-3 rounded-lg p-2 transition-colors hover:bg-slate-50">
                  <div className="mt-0.5 rounded-full bg-rose-100 p-1">
                    <span className="text-xs font-bold text-rose-700">3</span>
                  </div>
                  <p className="text-sm">Open and max out a Roth IRA ($6,500/year)</p>
                </div>
              </div>
            </div>

            <Button variant="outline" className="w-full border-violet-200 hover:bg-violet-50 hover:text-violet-700">
              Adjust Retirement Goals
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
