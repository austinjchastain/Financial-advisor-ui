import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { AlertTriangle, ArrowDown, CreditCard, Landmark, Car } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DebtStrategy() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Debt Strategy</h2>
          <p className="text-muted-foreground">Optimize your debt repayment plan</p>
        </div>
        <div className="flex items-center gap-2 rounded-lg bg-rose-50 px-3 py-1 text-rose-700">
          <AlertTriangle className="h-4 w-4" />
          <span className="text-sm font-medium">Priority 1</span>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-violet-400 to-violet-600"></div>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Total Debt</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$300,000</div>
            <p className="text-sm text-muted-foreground">Across all accounts</p>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-violet-400 to-violet-600"></div>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Monthly Payments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$2,050</div>
            <p className="text-sm text-muted-foreground">Total monthly obligation</p>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-violet-400 to-violet-600"></div>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Avg. Interest Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">4.8%</div>
            <p className="text-sm text-muted-foreground">Weighted average</p>
          </CardContent>
        </Card>
      </div>

      <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
        <CardHeader>
          <CardTitle>Current Obligations</CardTitle>
          <CardDescription>Your active debt accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {[
              {
                name: "Credit Card",
                icon: CreditCard,
                balance: 5000,
                rate: 18,
                payment: 200,
                progress: 16,
                payoff: "2027",
                priority: "High",
              },
              {
                name: "Auto Loan",
                icon: Car,
                balance: 15000,
                rate: 5.2,
                payment: 350,
                progress: 2,
                payoff: "2028",
                priority: "Medium",
              },
              {
                name: "Mortgage",
                icon: Landmark,
                balance: 280000,
                rate: 4.5,
                payment: 1500,
                progress: 0,
                payoff: "2040",
                priority: "Low",
              },
            ].map((debt, i) => (
              <div
                key={i}
                className="group relative overflow-hidden rounded-lg border border-slate-200 bg-white p-4 transition-all hover:shadow-sm"
              >
                <div className="absolute -right-12 -top-12 h-24 w-24 rounded-full bg-gradient-to-br from-slate-100 to-white opacity-0 transition-all group-hover:opacity-70"></div>
                <div className="relative flex flex-col justify-between gap-4 md:flex-row md:items-center">
                  <div className="flex items-center gap-3">
                    <div
                      className={`rounded-full ${
                        debt.priority === "High"
                          ? "bg-rose-100"
                          : debt.priority === "Medium"
                            ? "bg-amber-100"
                            : "bg-violet-100"
                      } p-2`}
                    >
                      <debt.icon
                        className={`h-5 w-5 ${
                          debt.priority === "High"
                            ? "text-rose-600"
                            : debt.priority === "Medium"
                              ? "text-amber-600"
                              : "text-violet-600"
                        }`}
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{debt.name}</h3>
                        {debt.priority === "High" && (
                          <span className="rounded-full bg-rose-100 px-2 py-0.5 text-xs font-medium text-rose-700">
                            Priority
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        ${debt.balance.toLocaleString()} at {debt.rate}% APR
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 md:flex md:items-center md:gap-6">
                    <div>
                      <p className="text-sm text-muted-foreground">Monthly</p>
                      <p className="font-medium">${debt.payment}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Payoff</p>
                      <p className="font-medium">{debt.payoff}</p>
                    </div>
                    <div className="col-span-2 md:w-32">
                      <div className="flex items-center justify-between text-xs">
                        <span>Progress</span>
                        <span>{debt.progress}%</span>
                      </div>
                      <Progress
                        value={debt.progress}
                        className="h-1.5 bg-slate-100"
                        indicatorClassName={
                          debt.priority === "High"
                            ? "bg-rose-500"
                            : debt.priority === "Medium"
                              ? "bg-amber-500"
                              : "bg-violet-500"
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
        <CardHeader>
          <CardTitle>Payoff Strategy</CardTitle>
          <CardDescription>Optimize your debt repayment approach</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="avalanche">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="avalanche">Avalanche Method</TabsTrigger>
              <TabsTrigger value="snowball">Snowball Method</TabsTrigger>
            </TabsList>

            <TabsContent value="avalanche" className="mt-4 space-y-4">
              <div className="rounded-lg bg-slate-100 p-4">
                <h4 className="font-medium">Highest Interest First</h4>
                <p className="text-sm text-muted-foreground">
                  Pay minimum on all debts, then put extra money toward the highest interest rate debt first. This saves
                  the most money long-term.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
                  <div className="mt-0.5 rounded-full bg-rose-100 p-1.5">
                    <ArrowDown className="h-4 w-4 text-rose-600" />
                  </div>
                  <div>
                    <p className="font-medium">Focus on Credit Card First</p>
                    <p className="text-sm text-muted-foreground">
                      With 18% APR, your credit card is costing you the most in interest. Allocate an extra $300/month
                      to pay it off by mid-2025.
                    </p>
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 bg-white p-4">
                  <h4 className="font-medium">Projected Timeline</h4>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Credit Card</span>
                      <span className="font-medium">Paid off by June 2025</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Auto Loan</span>
                      <span className="font-medium">Paid off by March 2028</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Mortgage</span>
                      <span className="font-medium">Paid off by October 2040</span>
                    </div>
                  </div>
                </div>
              </div>

              <Button className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                Apply Avalanche Strategy
              </Button>
            </TabsContent>

            <TabsContent value="snowball" className="mt-4 space-y-4">
              <div className="rounded-lg bg-slate-100 p-4">
                <h4 className="font-medium">Smallest Balance First</h4>
                <p className="text-sm text-muted-foreground">
                  Pay minimum on all debts, then put extra money toward the smallest balance debt first. This gives
                  psychological wins that can keep you motivated.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
                  <div className="mt-0.5 rounded-full bg-rose-100 p-1.5">
                    <ArrowDown className="h-4 w-4 text-rose-600" />
                  </div>
                  <div>
                    <p className="font-medium">Focus on Credit Card First</p>
                    <p className="text-sm text-muted-foreground">
                      With the smallest balance of $5,000, your credit card can be paid off quickly, giving you momentum
                      for tackling larger debts.
                    </p>
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 bg-white p-4">
                  <h4 className="font-medium">Projected Timeline</h4>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Credit Card</span>
                      <span className="font-medium">Paid off by June 2025</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Auto Loan</span>
                      <span className="font-medium">Paid off by March 2028</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Mortgage</span>
                      <span className="font-medium">Paid off by October 2040</span>
                    </div>
                  </div>
                </div>
              </div>

              <Button className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                Apply Snowball Strategy
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
