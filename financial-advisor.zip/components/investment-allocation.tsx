import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { AlertCircle, ArrowRight, PieChart, TrendingUp } from "lucide-react"

export default function InvestmentAllocation() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Investment Portfolio</h2>
          <p className="text-muted-foreground">Asset allocation and investment strategy</p>
        </div>
        <div className="flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-1 text-amber-700">
          <AlertCircle className="h-4 w-4" />
          <span className="text-sm font-medium">Priority 4</span>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
          <CardHeader>
            <CardTitle>Current Allocation</CardTitle>
            <CardDescription>Your investment mix</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="aspect-square max-w-[240px] mx-auto">
              <div className="relative h-full w-full rounded-full">
                {/* This would be a proper chart in a real implementation */}
                <div
                  className="absolute inset-0 rounded-full border-[12px] border-violet-500"
                  style={{ clipPath: "polygon(0 0, 60% 0, 60% 100%, 0 100%)" }}
                ></div>
                <div
                  className="absolute inset-0 rounded-full border-[12px] border-amber-400"
                  style={{ clipPath: "polygon(60% 0, 90% 0, 90% 100%, 60% 100%)" }}
                ></div>
                <div
                  className="absolute inset-0 rounded-full border-[12px] border-slate-300"
                  style={{ clipPath: "polygon(90% 0, 100% 0, 100% 100%, 90% 100%)" }}
                ></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <PieChart className="h-12 w-12 text-muted-foreground" />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-violet-500"></div>
                  <span className="text-sm font-medium">Stocks</span>
                </div>
                <span className="text-sm font-medium">60%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-amber-400"></div>
                  <span className="text-sm font-medium">Bonds</span>
                </div>
                <span className="text-sm font-medium">30%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-slate-300"></div>
                  <span className="text-sm font-medium">Cash</span>
                </div>
                <span className="text-sm font-medium">10%</span>
              </div>
            </div>

            <div className="rounded-lg bg-amber-50 p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="mt-0.5 h-5 w-5 text-amber-600" />
                <div>
                  <p className="font-medium text-amber-800">Diversification Needed</p>
                  <p className="text-sm text-amber-700">
                    Your investments appear concentrated. Consider spreading investments across different asset types
                    and geographic regions.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
          <CardHeader>
            <CardTitle>Recommended Allocation</CardTitle>
            <CardDescription>Optimized for your risk profile</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Stocks</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm">60%</span>
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-sm font-medium">75%</span>
                </div>
              </div>
              <Progress value={60} className="h-2 bg-slate-100" indicatorClassName="bg-violet-500">
                <div className="h-full bg-violet-500/30" style={{ width: "75%" }}></div>
              </Progress>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Bonds</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm">30%</span>
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-sm font-medium">20%</span>
                </div>
              </div>
              <Progress value={30} className="h-2 bg-slate-100" indicatorClassName="bg-amber-400">
                <div className="h-full bg-amber-400/30" style={{ width: "20%" }}></div>
              </Progress>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Cash</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm">10%</span>
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-sm font-medium">5%</span>
                </div>
              </div>
              <Progress value={10} className="h-2 bg-slate-100" indicatorClassName="bg-slate-300">
                <div className="h-full bg-slate-300/30" style={{ width: "5%" }}></div>
              </Progress>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-4">
              <h4 className="font-medium">Rebalancing Plan</h4>
              <p className="mt-1 text-sm text-muted-foreground">
                Move $7,500 from Bonds into Stocks to match your target allocation.
              </p>
              <div className="mt-4 flex items-center justify-between text-sm">
                <span>Risk Profile</span>
                <span className="font-medium">Moderate (6/10)</span>
              </div>
            </div>

            <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
              <div className="mt-0.5 rounded-full bg-violet-100 p-1.5">
                <TrendingUp className="h-4 w-4 text-violet-600" />
              </div>
              <div>
                <p className="font-medium">Why this matters</p>
                <p className="text-sm text-muted-foreground">
                  Shifting 15% more into stocks aligns with your moderate risk tolerance and can boost long-term growth
                  potential.
                </p>
              </div>
            </div>

            <Button className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
              Rebalance Portfolio
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
        <CardHeader>
          <CardTitle>Monthly Investment Plan</CardTitle>
          <CardDescription>Your automated growth strategy</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Current Monthly</span>
                <span className="text-xl font-bold">$1,830</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Target Monthly</span>
                <span className="text-xl font-bold">$2,200</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Contribution Gap</span>
                <span className="text-xl font-bold text-amber-600">-$370</span>
              </div>

              <div className="rounded-lg bg-slate-100 p-4">
                <h4 className="font-medium">Net Worth</h4>
                <div className="mt-2 text-2xl font-bold">$125,000</div>
                <p className="text-xs text-muted-foreground">+15% from last year</p>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Account Allocations</h4>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-violet-500"></div>
                    <span className="text-sm">401(k)</span>
                  </div>
                  <span className="text-sm font-medium">$730</span>
                </div>
                <Progress value={40} className="h-1.5 bg-slate-100" indicatorClassName="bg-violet-500" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-purple-500"></div>
                    <span className="text-sm">IRA</span>
                  </div>
                  <span className="text-sm font-medium">$550</span>
                </div>
                <Progress value={30} className="h-1.5 bg-slate-100" indicatorClassName="bg-purple-500" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-amber-500"></div>
                    <span className="text-sm">Taxable Brokerage</span>
                  </div>
                  <span className="text-sm font-medium">$370</span>
                </div>
                <Progress value={20} className="h-1.5 bg-slate-100" indicatorClassName="bg-amber-500" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-slate-400"></div>
                    <span className="text-sm">529 College Plan</span>
                  </div>
                  <span className="text-sm font-medium">$180</span>
                </div>
                <Progress value={10} className="h-1.5 bg-slate-100" indicatorClassName="bg-slate-400" />
              </div>

              <Button variant="outline" className="w-full border-violet-200 hover:bg-violet-50 hover:text-violet-700">
                Adjust Contributions
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
