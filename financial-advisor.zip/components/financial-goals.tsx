import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { GraduationCap, Home, Plane, FileText } from "lucide-react"

export default function FinancialGoals() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Financial Goals</h2>
          <p className="text-muted-foreground">Long-term planning and milestones</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="group relative overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md transition-all hover:shadow-lg">
          <div className="absolute -right-16 -top-16 h-32 w-32 rounded-full bg-gradient-to-br from-violet-100 to-violet-50 opacity-0 transition-all group-hover:opacity-70"></div>
          <CardHeader className="relative">
            <CardTitle>Estate Planning</CardTitle>
            <CardDescription>Protect your assets and loved ones</CardDescription>
          </CardHeader>
          <CardContent className="relative space-y-6">
            <div className="space-y-4">
              <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
                <div className="mt-0.5 rounded-full bg-slate-100 p-2">
                  <FileText className="h-5 w-5 text-slate-600" />
                </div>
                <div>
                  <p className="font-medium">Basic Estate Documents</p>
                  <p className="text-sm text-muted-foreground">
                    Ensure you have basic estate documents in place: a will, power of attorney, and healthcare
                    directive. These are especially important if you have children or significant assets.
                  </p>
                </div>
              </div>

              <div className="rounded-lg border border-slate-200 bg-white p-4">
                <h4 className="font-medium">Estate Planning Checklist</h4>
                <div className="mt-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded border border-muted"></div>
                    <span className="text-sm">Create a will</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded border border-muted"></div>
                    <span className="text-sm">Establish power of attorney</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded border border-muted"></div>
                    <span className="text-sm">Create healthcare directive</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded border border-muted"></div>
                    <span className="text-sm">Review beneficiary designations</span>
                  </div>
                </div>
              </div>
            </div>

            <Button variant="outline" className="w-full border-violet-200 hover:bg-violet-50 hover:text-violet-700">
              Start Estate Planning
            </Button>
          </CardContent>
        </Card>

        <Card className="group relative overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md transition-all hover:shadow-lg">
          <div className="absolute -right-16 -top-16 h-32 w-32 rounded-full bg-gradient-to-br from-amber-100 to-amber-50 opacity-0 transition-all group-hover:opacity-70"></div>
          <CardHeader className="relative">
            <CardTitle>Education Planning</CardTitle>
            <CardDescription>Save for future education expenses</CardDescription>
          </CardHeader>
          <CardContent className="relative space-y-6">
            <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
              <div className="mt-0.5 rounded-full bg-amber-100 p-2">
                <GraduationCap className="h-5 w-5 text-amber-600" />
              </div>
              <div>
                <p className="font-medium">529 College Savings Plan</p>
                <p className="text-sm text-muted-foreground">
                  Consider establishing a 529 college savings plan for your children. These plans offer tax-advantaged
                  growth for education expenses.
                </p>
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-4">
              <h4 className="font-medium">Education Fund</h4>
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Current savings</span>
                  <span className="font-medium">$5,000</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Target amount</span>
                  <span className="font-medium">$80,000</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Progress</span>
                  <span className="font-medium">6%</span>
                </div>
                <Progress value={6} className="h-1.5 bg-slate-100" indicatorClassName="bg-amber-500" />
              </div>
            </div>

            <Button className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700">
              Open 529 Plan
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="group relative overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md transition-all hover:shadow-lg">
          <div className="absolute -right-16 -top-16 h-32 w-32 rounded-full bg-gradient-to-br from-violet-100 to-violet-50 opacity-0 transition-all group-hover:opacity-70"></div>
          <CardHeader className="relative">
            <CardTitle>Home Purchase</CardTitle>
            <CardDescription>Save for a down payment</CardDescription>
          </CardHeader>
          <CardContent className="relative space-y-6">
            <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
              <div className="mt-0.5 rounded-full bg-violet-100 p-2">
                <Home className="h-5 w-5 text-violet-600" />
              </div>
              <div>
                <p className="font-medium">Down Payment Fund</p>
                <p className="text-sm text-muted-foreground">
                  Building a dedicated savings fund for a future home purchase will help you reach your goal of
                  homeownership.
                </p>
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-4">
              <h4 className="font-medium">Home Purchase Fund</h4>
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Current savings</span>
                  <span className="font-medium">$20,000</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Target down payment</span>
                  <span className="font-medium">$60,000</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Progress</span>
                  <span className="font-medium">33%</span>
                </div>
                <Progress value={33} className="h-1.5 bg-slate-100" indicatorClassName="bg-violet-500" />
              </div>
            </div>

            <Button variant="outline" className="w-full border-violet-200 hover:bg-violet-50 hover:text-violet-700">
              Adjust Home Savings Plan
            </Button>
          </CardContent>
        </Card>

        <Card className="group relative overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md transition-all hover:shadow-lg">
          <div className="absolute -right-16 -top-16 h-32 w-32 rounded-full bg-gradient-to-br from-teal-100 to-teal-50 opacity-0 transition-all group-hover:opacity-70"></div>
          <CardHeader className="relative">
            <CardTitle>Travel Fund</CardTitle>
            <CardDescription>Save for experiences</CardDescription>
          </CardHeader>
          <CardContent className="relative space-y-6">
            <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
              <div className="mt-0.5 rounded-full bg-teal-100 p-2">
                <Plane className="h-5 w-5 text-teal-600" />
              </div>
              <div>
                <p className="font-medium">Vacation Savings</p>
                <p className="text-sm text-muted-foreground">
                  Beyond retirement, identify your major life goals with financial implications. Create separate savings
                  strategies for each.
                </p>
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-4">
              <h4 className="font-medium">Travel Fund</h4>
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Current savings</span>
                  <span className="font-medium">$2,500</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Annual target</span>
                  <span className="font-medium">$5,000</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Progress</span>
                  <span className="font-medium">50%</span>
                </div>
                <Progress value={50} className="h-1.5 bg-slate-100" indicatorClassName="bg-teal-500" />
              </div>
            </div>

            <Button variant="outline" className="w-full border-teal-200 hover:bg-teal-50 hover:text-teal-700">
              Adjust Travel Fund
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
