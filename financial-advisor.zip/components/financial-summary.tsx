import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowUpRight, TrendingUp, Wallet, AlertTriangle, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function FinancialSummary() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold tracking-tight">Financial Health Overview</h2>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-violet-400 to-violet-600"></div>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Net Worth</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$125,000</div>
            <p className="text-xs text-muted-foreground">+12% from last year</p>
            <Progress value={65} className="mt-3 h-1.5 bg-slate-100" indicatorClassName="bg-violet-500" />
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-teal-400 to-teal-600"></div>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Monthly Savings</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$1,830</div>
            <p className="text-xs text-muted-foreground">18% of income</p>
            <Progress value={75} className="mt-3 h-1.5 bg-slate-100" indicatorClassName="bg-teal-500" />
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-amber-400 to-amber-600"></div>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Debt-to-Income</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">102%</div>
            <p className="text-xs text-amber-500">Above recommended range</p>
            <Progress value={85} className="mt-3 h-1.5 bg-slate-100" indicatorClassName="bg-amber-500" />
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-rose-400 to-rose-600"></div>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Retirement Readiness</CardTitle>
            <ShieldCheck className="h-4 w-4 text-rose-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32%</div>
            <p className="text-xs text-rose-500">Needs immediate attention</p>
            <Progress value={32} className="mt-3 h-1.5 bg-slate-100" indicatorClassName="bg-rose-500" />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
          <CardHeader>
            <CardTitle>Priority Actions</CardTitle>
            <CardDescription>Focus on these key areas first</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  title: "Pay down high-interest debt",
                  description: "Focus on your credit card with 18% APR",
                  priority: "Urgent",
                  color: "rose",
                },
                {
                  title: "Increase retirement contributions",
                  description: "You're behind on retirement savings goals",
                  priority: "High",
                  color: "amber",
                },
                {
                  title: "Complete emergency fund",
                  description: "Add $3,000 to reach 6-month target",
                  priority: "Medium",
                  color: "violet",
                },
              ].map((action, i) => (
                <div key={i} className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
                  <div className={`mt-0.5 rounded-full bg-${action.color}-100 p-1.5`}>
                    <ArrowUpRight className={`h-3.5 w-3.5 text-${action.color}-600`} />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{action.title}</p>
                      <span
                        className={`rounded-full bg-${action.color}-100 px-2 py-0.5 text-xs font-medium text-${action.color}-700`}
                      >
                        {action.priority}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{action.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
          <CardHeader>
            <CardTitle>Financial Strengths</CardTitle>
            <CardDescription>Areas where you're doing well</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  title: "Positive cash flow",
                  description: "You spend less than you earn, creating a monthly surplus",
                },
                {
                  title: "Emergency fund started",
                  description: "You have 3 months of expenses saved for emergencies",
                },
                {
                  title: "Regular investing habit",
                  description: "You're consistently investing $1,830 monthly",
                },
              ].map((strength, i) => (
                <div key={i} className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
                  <div className="mt-0.5 rounded-full bg-teal-100 p-1.5">
                    <ShieldCheck className="h-3.5 w-3.5 text-teal-600" />
                  </div>
                  <div className="space-y-1">
                    <p className="font-medium">{strength.title}</p>
                    <p className="text-sm text-muted-foreground">{strength.description}</p>
                  </div>
                </div>
              ))}

              <Button className="mt-4 w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                View Full Analysis
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
