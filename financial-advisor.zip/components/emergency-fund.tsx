import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle2, PiggyBank, TrendingUp } from "lucide-react"

export default function EmergencyFund() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Emergency Fund</h2>
          <p className="text-muted-foreground">Your financial safety net</p>
        </div>
        <div className="flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-1 text-amber-700">
          <AlertCircle className="h-4 w-4" />
          <span className="text-sm font-medium">Priority 2</span>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
          <CardHeader>
            <CardTitle>Savings Progress</CardTitle>
            <CardDescription>Current emergency fund status</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold">$15,000</div>
                <div className="text-sm text-muted-foreground">Current savings</div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold">$18,000</div>
                <div className="text-sm text-muted-foreground">Target (6 months)</div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Funding Progress</span>
                <span className="font-medium">83%</span>
              </div>
              <Progress value={83} className="h-2 bg-slate-100" indicatorClassName="bg-violet-500" />
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>$0</span>
                <span>$18,000</span>
              </div>
            </div>

            <div className="rounded-lg bg-teal-50 p-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="mt-0.5 h-5 w-5 text-teal-600" />
                <div>
                  <p className="font-medium text-teal-800">Good progress!</p>
                  <p className="text-sm text-teal-700">
                    You've built about 3 months of emergency savings – a solid foundation.
                  </p>
                </div>
              </div>
            </div>

            <Button className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
              Add to Emergency Fund
            </Button>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-none bg-gradient-to-br from-slate-50 to-white shadow-md">
          <CardHeader>
            <CardTitle>Recommendations</CardTitle>
            <CardDescription>Next steps for your emergency fund</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
                <div className="mt-0.5 rounded-full bg-amber-100 p-1.5">
                  <TrendingUp className="h-4 w-4 text-amber-600" />
                </div>
                <div>
                  <p className="font-medium">Increase to 6 months</p>
                  <p className="text-sm text-muted-foreground">
                    To be extra secure, especially for unexpected job or health issues, consider extending your
                    emergency fund to 6 months of expenses.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 rounded-lg p-3 transition-colors hover:bg-slate-50">
                <div className="mt-0.5 rounded-full bg-teal-100 p-1.5">
                  <PiggyBank className="h-4 w-4 text-teal-600" />
                </div>
                <div>
                  <p className="font-medium">High-yield savings account</p>
                  <p className="text-sm text-muted-foreground">
                    Consider moving your emergency fund to a high-yield savings account to earn more interest while
                    maintaining liquidity.
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-4">
              <h4 className="font-medium">Savings Plan</h4>
              <div className="mt-2 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Current monthly contribution</span>
                  <span className="font-medium">$300</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Recommended monthly contribution</span>
                  <span className="font-medium">$500</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Months to reach target</span>
                  <span className="font-medium">6 months</span>
                </div>
              </div>
            </div>

            <Button variant="outline" className="w-full border-violet-200 hover:bg-violet-50 hover:text-violet-700">
              Adjust Savings Plan
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
