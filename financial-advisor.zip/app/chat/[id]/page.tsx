import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, ArrowRight, Send } from "lucide-react"
import Link from "next/link"

interface ChatPageProps {
  params: {
    id: string
  }
}

export default function ChatPage({ params }: ChatPageProps) {
  const chatId = Number.parseInt(params.id)
  const nextChatId = chatId < 8 ? chatId + 1 : 8
  const chatTopics = [
    { id: 1, title: "Risk Tolerance", question: "On a scale of 1-10, how comfortable are you with investment risk?" },
    {
      id: 2,
      title: "Retirement Lifestyle",
      question: "What lifestyle do you expect in retirement compared to now?",
    },
    { id: 3, title: "Retirement Travel", question: "What's your annual travel budget for retirement?" },
    { id: 4, title: "College Funding", question: "How much do you plan to contribute to each child's education?" },
    {
      id: 5,
      title: "Emergency Fund",
      question: "How many months of expenses would you like in your emergency fund?",
    },
    { id: 6, title: "Credit Score", question: "What's your current credit score?" },
    { id: 7, title: "Financial Stress", question: "On a scale of 1-10, how stressed are you about your finances?" },
    {
      id: 8,
      title: "Financial Literacy",
      question: "On a scale of 1-10, how would you rate your financial knowledge?",
    },
  ]

  const currentChat = chatTopics.find((chat) => chat.id === chatId) || chatTopics[0]
  const suggestedReplies = getSuggestedReplies(chatId)

  return (
    <main className="min-h-screen pb-20">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-[#e5e5e7] bg-white/80 backdrop-blur-md">
        <div className="flex h-14 items-center px-6">
          <Link href={chatId === 1 ? "/intake" : `/chat/${chatId - 1}`} className="flex items-center text-[#0071e3]">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Link>
          <h1 className="mx-auto text-base font-medium">
            Chat {chatId}/8: {currentChat.title}
          </h1>
        </div>
      </header>

      <div className="flex flex-col p-6">
        <div className="mb-4 flex-1 space-y-4">
          {/* AI Message */}
          <div className="flex items-start gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#0071e3]">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 6v6l4 2" />
                <circle cx="12" cy="12" r="10" />
              </svg>
            </div>
            <Card className="max-w-[85%] border-[#e5e5e7] bg-[#f5f5f7]">
              <CardContent className="p-3 text-sm">{currentChat.question}</CardContent>
            </Card>
          </div>
        </div>

        {/* Suggested Replies */}
        <div className="mb-4 flex flex-wrap gap-2">
          {suggestedReplies.map((reply, index) => (
            <Button
              key={index}
              variant="outline"
              className="h-auto border-[#e5e5e7] px-3 py-2 text-xs hover:bg-[#f5f5f7]"
            >
              {reply}
            </Button>
          ))}
        </div>

        {/* Input Area */}
        <div className="flex items-center gap-2">
          <Input placeholder="Type your response..." className="border-[#e5e5e7]" />
          <Button size="icon" className="h-10 w-10 rounded-full bg-[#0071e3] hover:bg-[#0077ED]">
            <Send className="h-4 w-4" />
          </Button>
        </div>

        {/* Navigation Buttons */}
        <div className="mt-6 flex justify-between">
          <Link href="/results">
            <Button variant="outline" className="border-[#e5e5e7]">
              Skip to Results
            </Button>
          </Link>
          <Link href={`/chat/${nextChatId}`}>
            <Button className="bg-[#0071e3] hover:bg-[#0077ED]">
              Next <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </main>
  )
}

function getSuggestedReplies(chatId: number): string[] {
  switch (chatId) {
    case 1: // Risk Tolerance
      return ["1-3 (Conservative)", "4-7 (Moderate)", "8-10 (Aggressive)"]
    case 2: // Retirement Lifestyle
      return ["Below current", "Similar to current", "Above current"]
    case 3: // Retirement Travel
      return ["₹100,000/year", "₹300,000/year", "₹500,000+/year"]
    case 4: // College Funding
      return ["₹5 lakh per child", "₹10 lakh per child", "₹20 lakh per child"]
    case 5: // Emergency Fund
      return ["3 months", "6 months", "12 months"]
    case 6: // Credit Score
      return ["Below 650", "650-750", "Above 750"]
    case 7: // Financial Stress
      return ["1-3 (Low stress)", "4-7 (Moderate)", "8-10 (High stress)"]
    case 8: // Financial Literacy
      return ["1-3 (Beginner)", "4-7 (Intermediate)", "8-10 (Advanced)"]
    default:
      return ["Option 1", "Option 2", "Option 3"]
  }
}
