import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  BriefcaseBusiness,
  CreditCard,
  DollarSign,
  GraduationCap,
  Home,
  LineChart,
  PiggyBank,
  Shield,
  Wallet,
} from "lucide-react"

export default function ResultsPage() {
  return (
    <main className="min-h-screen pb-20">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-[#e5e5e7] bg-white/80 backdrop-blur-md">
        <div className="flex h-14 items-center justify-between px-6">
          <h1 className="text-lg font-semibold">Your Financial Plan</h1>
          <Button variant="ghost" size="sm" className="text-[#0071e3]">
            Share
          </Button>
        </div>
      </header>

      <div className="p-6 space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="border-[#e5e5e7] bg-gradient-to-br from-[#f5f5f7] to-white">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#0071e3]/10">
                  <Wallet className="h-4 w-4 text-[#0071e3]" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Net Worth</p>
                  <p className="text-base font-semibold">₹15.2L</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#e5e5e7] bg-gradient-to-br from-[#f5f5f7] to-white">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#30d158]/10">
                  <Shield className="h-4 w-4 text-[#30d158]" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Emergency Fund</p>
                  <p className="text-base font-semibold">3 months</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#e5e5e7] bg-gradient-to-br from-[#f5f5f7] to-white">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#ff453a]/10">
                  <CreditCard className="h-4 w-4 text-[#ff453a]" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Total Debt</p>
                  <p className="text-base font-semibold">₹3.0L</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#e5e5e7] bg-gradient-to-br from-[#f5f5f7] to-white">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#5e5ce6]/10">
                  <PiggyBank className="h-4 w-4 text-[#5e5ce6]" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Savings Rate</p>
                  <p className="text-base font-semibold">18%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Budget & Spending */}
        <Card className="border-[#e5e5e7]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Budget & Spending</CardTitle>
            <CardDescription>Monthly cash flow analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Monthly Income</p>
                  <p className="text-lg font-medium">₹1,00,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Monthly Expenses</p>
                  <p className="text-lg font-medium">₹82,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Surplus</p>
                  <p className="text-lg font-medium text-[#30d158]">₹18,000</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span>Housing (35%)</span>
                    <span>₹35,000</span>
                  </div>
                  <Progress value={35} className="h-1.5" />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span>Transportation (15%)</span>
                    <span>₹15,000</span>
                  </div>
                  <Progress value={15} className="h-1.5" indicatorClassName="bg-[#5e5ce6]" />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span>Food (20%)</span>
                    <span>₹20,000</span>
                  </div>
                  <Progress value={20} className="h-1.5" indicatorClassName="bg-[#30d158]" />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span>Debt Payments (12%)</span>
                    <span>₹12,000</span>
                  </div>
                  <Progress value={12} className="h-1.5" indicatorClassName="bg-[#ff453a]" />
                </div>
              </div>

              <div className="rounded-lg bg-[#f5f5f7] p-3">
                <div className="flex items-start gap-2">
                  <BadgeCheck className="mt-0.5 h-4 w-4 text-[#30d158]" />
                  <div>
                    <p className="text-sm font-medium">Recommendation</p>
                    <p className="text-xs text-muted-foreground">
                      Your savings rate of 18% is good. Consider allocating more to retirement and emergency fund.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Fund */}
        <Card className="border-[#e5e5e7]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Emergency Fund</CardTitle>
            <CardDescription>Your financial safety net</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Current</p>
                  <p className="text-lg font-medium">₹2,46,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Target (6 months)</p>
                  <p className="text-lg font-medium">₹4,92,000</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Progress</span>
                  <span className="font-medium">50%</span>
                </div>
                <Progress value={50} className="h-2" indicatorClassName="bg-[#ff9f0a]" />
              </div>

              <div className="rounded-lg bg-[#ff9f0a]/10 p-3">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 h-4 w-4 text-[#ff9f0a]" />
                  <div>
                    <p className="text-sm font-medium">Action Needed</p>
                    <p className="text-xs text-muted-foreground">
                      You're halfway to your 6-month emergency fund goal. Consider adding ₹10,000/month to reach your
                      target in 25 months.
                    </p>
                  </div>
                </div>
              </div>

              <Button className="w-full bg-[#0071e3] hover:bg-[#0077ED]">Set Up Automatic Transfers</Button>
            </div>
          </CardContent>
        </Card>

        {/* Debt Strategy */}
        <Card className="border-[#e5e5e7]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Debt Strategy</CardTitle>
            <CardDescription>Optimize your debt repayment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Debt</p>
                  <p className="text-lg font-medium">₹3,00,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Monthly Payments</p>
                  <p className="text-lg font-medium">₹12,000</p>
                </div>
              </div>

              <div className="rounded-lg border border-[#e5e5e7] bg-white p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#ff453a]/10">
                      <CreditCard className="h-4 w-4 text-[#ff453a]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Credit Card</p>
                      <p className="text-xs text-muted-foreground">18% APR</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">₹75,000</p>
                    <p className="text-xs text-[#ff453a]">Highest Priority</p>
                  </div>
                </div>
              </div>

              <Tabs defaultValue="avalanche">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="avalanche">Avalanche Method</TabsTrigger>
                  <TabsTrigger value="snowball">Snowball Method</TabsTrigger>
                </TabsList>
                <TabsContent value="avalanche" className="mt-4 space-y-3">
                  <p className="text-xs text-muted-foreground">
                    Pay minimum on all debts, then put extra money toward the highest interest rate debt first. This
                    saves you the most money in interest over time.
                  </p>
                  <Button className="w-full bg-[#ff453a] hover:bg-[#ff453a]/90">Pay Off Credit Card Now</Button>
                </TabsContent>
                <TabsContent value="snowball" className="mt-4 space-y-3">
                  <p className="text-xs text-muted-foreground">
                    Pay minimum on all debts, then put extra money toward the smallest balance debt first. This gives
                    you psychological wins that can keep you motivated.
                  </p>
                  <Button className="w-full bg-[#ff453a] hover:bg-[#ff453a]/90">Pay Off Personal Loan Now</Button>
                </TabsContent>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Assets & Investing */}
        <Card className="border-[#e5e5e7]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Assets & Investing</CardTitle>
            <CardDescription>Portfolio allocation strategy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Investments</p>
                  <p className="text-lg font-medium">₹12,50,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Monthly Contribution</p>
                  <p className="text-lg font-medium">₹15,000</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-lg bg-[#f5f5f7] p-3">
                  <p className="mb-2 text-xs font-medium">Current Allocation</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-[#0071e3]"></div>
                        <span>Stocks (40%)</span>
                      </div>
                      <span>₹5,00,000</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-[#5e5ce6]"></div>
                        <span>Bonds (50%)</span>
                      </div>
                      <span>₹6,25,000</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-[#30d158]"></div>
                        <span>Cash (10%)</span>
                      </div>
                      <span>₹1,25,000</span>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg bg-[#f5f5f7] p-3">
                  <p className="mb-2 text-xs font-medium">Target Allocation</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-[#0071e3]"></div>
                        <span>Stocks (70%)</span>
                      </div>
                      <span>₹8,75,000</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-[#5e5ce6]"></div>
                        <span>Bonds (25%)</span>
                      </div>
                      <span>₹3,12,500</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-[#30d158]"></div>
                        <span>Cash (5%)</span>
                      </div>
                      <span>₹62,500</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="rounded-lg bg-[#0071e3]/10 p-3">
                <div className="flex items-start gap-2">
                  <LineChart className="mt-0.5 h-4 w-4 text-[#0071e3]" />
                  <div>
                    <p className="text-sm font-medium">Rebalance Needed</p>
                    <p className="text-xs text-muted-foreground">
                      Your portfolio is too conservative for your age and goals. Consider shifting ₹3,75,000 from bonds
                      to stocks.
                    </p>
                  </div>
                </div>
              </div>

              <Button className="w-full bg-[#0071e3] hover:bg-[#0077ED]">Rebalance Portfolio</Button>
            </div>
          </CardContent>
        </Card>

        {/* Retirement Summary */}
        <Card className="border-[#e5e5e7]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Retirement Planning</CardTitle>
            <CardDescription>Long-term financial security</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-lg bg-[#f5f5f7] p-3 text-center">
                  <p className="text-xs text-muted-foreground">Current Age</p>
                  <p className="text-lg font-medium">35</p>
                </div>
                <div className="rounded-lg bg-[#f5f5f7] p-3 text-center">
                  <p className="text-xs text-muted-foreground">Retirement Age</p>
                  <p className="text-lg font-medium">60</p>
                </div>
                <div className="rounded-lg bg-[#f5f5f7] p-3 text-center">
                  <p className="text-xs text-muted-foreground">Years Left</p>
                  <p className="text-lg font-medium">25</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Retirement Readiness</span>
                  <span className="font-medium text-[#ff9f0a]">42%</span>
                </div>
                <Progress value={42} className="h-2" indicatorClassName="bg-[#ff9f0a]" />
                <p className="text-xs text-muted-foreground">
                  You're on track to have ₹42,00,000 at retirement, which is 42% of your estimated need of ₹1,00,00,000.
                </p>
              </div>

              <div className="rounded-lg bg-[#f5f5f7] p-3">
                <div className="flex items-start gap-2">
                  <BriefcaseBusiness className="mt-0.5 h-4 w-4 text-[#0071e3]" />
                  <div>
                    <p className="text-sm font-medium">Key Action</p>
                    <p className="text-xs text-muted-foreground">
                      Increase your retirement contributions by ₹10,000/month to reach your retirement goal.
                    </p>
                  </div>
                </div>
              </div>

              <Button variant="outline" className="w-full border-[#0071e3] text-[#0071e3] hover:bg-[#0071e3]/10">
                Adjust Retirement Plan
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* College Plan */}
        <Card className="border-[#e5e5e7]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Education Planning</CardTitle>
            <CardDescription>College funding strategy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="rounded-lg border border-[#e5e5e7] bg-white p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#5e5ce6]/10">
                      <GraduationCap className="h-4 w-4 text-[#5e5ce6]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Child 1 (Age 8)</p>
                      <p className="text-xs text-muted-foreground">College in 10 years</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">₹2,50,000</p>
                    <p className="text-xs text-muted-foreground">Current savings</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Funding Progress</span>
                  <span className="font-medium">25%</span>
                </div>
                <Progress value={25} className="h-2" indicatorClassName="bg-[#5e5ce6]" />
                <p className="text-xs text-muted-foreground">
                  Estimated college cost: ₹10,00,000. You need to save ₹6,250/month to reach your goal.
                </p>
              </div>

              <Button className="w-full bg-[#5e5ce6] hover:bg-[#5e5ce6]/90">Open 529 College Plan</Button>
            </div>
          </CardContent>
        </Card>

        {/* Other Goals */}
        <Card className="border-[#e5e5e7]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Other Financial Goals</CardTitle>
            <CardDescription>Additional savings targets</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="rounded-lg border border-[#e5e5e7] bg-white p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#30d158]/10">
                      <Home className="h-4 w-4 text-[#30d158]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Home Down Payment</p>
                      <p className="text-xs text-muted-foreground">Target: 3 years</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">₹5,00,000</p>
                    <p className="text-xs text-muted-foreground">of ₹15,00,000</p>
                  </div>
                </div>
                <Progress value={33} className="mt-3 h-1.5" indicatorClassName="bg-[#30d158]" />
              </div>

              <div className="rounded-lg border border-[#e5e5e7] bg-white p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#ff9f0a]/10">
                      <DollarSign className="h-4 w-4 text-[#ff9f0a]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Vacation Fund</p>
                      <p className="text-xs text-muted-foreground">Target: 1 year</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">₹50,000</p>
                    <p className="text-xs text-muted-foreground">of ₹2,00,000</p>
                  </div>
                </div>
                <Progress value={25} className="mt-3 h-1.5" indicatorClassName="bg-[#ff9f0a]" />
              </div>

              <Button variant="outline" className="w-full border-[#0071e3] text-[#0071e3] hover:bg-[#0071e3]/10">
                Add New Goal
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Prioritized Actions */}
        <div className="space-y-4">
          <h2 className="text-lg font-medium">Prioritized Actions</h2>

          <Card className="border-[#e5e5e7] bg-[#ff453a]/5">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#ff453a]/10">
                  <AlertTriangle className="h-5 w-5 text-[#ff453a]" />
                </div>
                <div>
                  <p className="font-medium">Immediate: Pay off credit card</p>
                  <p className="text-sm text-muted-foreground">
                    Your 18% APR credit card is costing you ₹13,500 in interest annually. Pay this off immediately.
                  </p>
                  <Button className="mt-3 bg-[#ff453a] hover:bg-[#ff453a]/90">
                    Take Action <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#e5e5e7] bg-[#ff9f0a]/5">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#ff9f0a]/10">
                  <Shield className="h-5 w-5 text-[#ff9f0a]" />
                </div>
                <div>
                  <p className="font-medium">Next Step: Complete emergency fund</p>
                  <p className="text-sm text-muted-foreground">
                    Add ₹10,000/month to your emergency fund to reach your 6-month target in 25 months.
                  </p>
                  <Button className="mt-3 bg-[#ff9f0a] hover:bg-[#ff9f0a]/90">
                    Take Action <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#e5e5e7] bg-[#0071e3]/5">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#0071e3]/10">
                  <LineChart className="h-5 w-5 text-[#0071e3]" />
                </div>
                <div>
                  <p className="font-medium">Future: Rebalance investments</p>
                  <p className="text-sm text-muted-foreground">
                    Shift ₹3,75,000 from bonds to stocks to align with your long-term growth goals.
                  </p>
                  <Button className="mt-3 bg-[#0071e3] hover:bg-[#0077ED]">
                    Take Action <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
