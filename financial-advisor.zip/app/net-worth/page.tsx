import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowUpRight, Building, Coins, DollarSign, Home, PlusCircle, Wallet } from "lucide-react"

export default function NetWorth() {
  return (
    <main className="min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <div>
          <h1 className="text-xl font-medium">Net Worth</h1>
          <p className="text-sm text-muted-foreground">Track your assets in real-time</p>
        </div>
        <Avatar>
          <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Kumar" />
          <AvatarFallback>KM</AvatarFallback>
        </Avatar>
      </div>

      {/* Net Worth Summary */}
      <div className="px-4">
        <Card className="overflow-hidden border-none bg-gradient-to-br from-[#f5f5f7] to-white shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Total Net Worth</CardTitle>
            <CardDescription>Updated in real-time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-3xl font-semibold">₹24,56,780</p>
                <p className="text-sm text-[#30d158]">+₹45,320 (1.8%) this month</p>
              </div>
              <Button className="bg-[#0071e3] hover:bg-[#0077ED]">
                <PlusCircle className="mr-2 h-4 w-4" /> Add Asset
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Asset Categories */}
      <div className="mt-6 px-6">
        <h2 className="mb-4 text-lg font-medium">Asset Categories</h2>
        <div className="space-y-4">
          {[
            {
              icon: Coins,
              name: "Investments",
              amount: "₹12,45,600",
              percentage: 50.7,
              change: "+2.3%",
              positive: true,
            },
            {
              icon: Wallet,
              name: "Cash",
              amount: "₹3,25,000",
              percentage: 13.2,
              change: "+0.5%",
              positive: true,
            },
            {
              icon: Home,
              name: "Real Estate",
              amount: "₹8,50,000",
              percentage: 34.6,
              change: "+0.0%",
              positive: true,
            },
            {
              icon: Building,
              name: "Collectibles",
              amount: "₹36,180",
              percentage: 1.5,
              change: "-1.2%",
              positive: false,
            },
          ].map((asset, i) => (
            <Card key={i} className="border-[#e5e5e7]">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#f5f5f7]">
                      <asset.icon className="h-5 w-5 text-[#1d1d1f]" />
                    </div>
                    <div>
                      <p className="font-medium">{asset.name}</p>
                      <p className="text-xs text-muted-foreground">{asset.percentage}% of total</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{asset.amount}</p>
                    <p className={`text-xs ${asset.positive ? "text-[#30d158]" : "text-[#ff453a]"}`}>{asset.change}</p>
                  </div>
                </div>
                <Progress
                  value={asset.percentage}
                  className="mt-3 h-1.5"
                  indicatorClassName={
                    i === 0 ? "bg-[#0071e3]" : i === 1 ? "bg-[#5e5ce6]" : i === 2 ? "bg-[#30d158]" : "bg-[#ff9f0a]"
                  }
                />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Integration Info */}
      <div className="mt-6 px-6">
        <Card className="border-[#e5e5e7] bg-[#f5f5f7]">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#0071e3]">
                <DollarSign className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-medium">Connected Accounts</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Connects with over 10,000 accounts and wallets across 16+ chains for automatic updates.
                </p>
                <Button
                  variant="outline"
                  className="mt-3 h-8 border-[#0071e3] text-xs text-[#0071e3] hover:bg-[#0071e3]/10"
                >
                  Manage Connections
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Updates */}
      <div className="mt-6 px-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-medium">Recent Updates</h2>
          <Button variant="ghost" className="h-8 text-xs text-[#0071e3]">
            See All
          </Button>
        </div>
        <div className="space-y-4">
          {[
            {
              title: "Stock Portfolio",
              description: "AAPL shares increased by 2.5%",
              time: "2 hours ago",
              positive: true,
            },
            {
              title: "Crypto Wallet",
              description: "BTC value decreased by 1.8%",
              time: "5 hours ago",
              positive: false,
            },
            {
              title: "Bank Account",
              description: "Salary credited: ₹85,000",
              time: "Yesterday",
              positive: true,
            },
          ].map((update, i) => (
            <div key={i} className="flex items-center justify-between rounded-xl border border-[#e5e5e7] p-3">
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full ${
                    update.positive ? "bg-[#30d158]/10" : "bg-[#ff453a]/10"
                  }`}
                >
                  <ArrowUpRight
                    className={`h-5 w-5 ${update.positive ? "text-[#30d158]" : "text-[#ff453a]"} ${
                      !update.positive && "rotate-180"
                    }`}
                  />
                </div>
                <div>
                  <p className="font-medium">{update.title}</p>
                  <p className="text-xs text-muted-foreground">{update.description}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">{update.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
