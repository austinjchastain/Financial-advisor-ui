import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowDownUp, ChevronDown, Search, TrendingUp } from "lucide-react"

export default function Trade() {
  return (
    <main className="min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <div>
          <h1 className="text-xl font-medium">Trade Center</h1>
          <p className="text-sm text-muted-foreground">Unified trading across accounts</p>
        </div>
        <Avatar>
          <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Kumar" />
          <AvatarFallback>KM</AvatarFallback>
        </Avatar>
      </div>

      {/* Brokerage Selection */}
      <div className="px-4">
        <Card className="overflow-hidden border-none bg-gradient-to-br from-[#f5f5f7] to-white shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Trading Account</CardTitle>
            <CardDescription>Select your brokerage</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full justify-between border-[#e5e5e7]">
              <div className="flex items-center gap-2">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-[#0071e3]">
                  <span className="text-xs font-medium text-white">Z</span>
                </div>
                <span>Zerodha</span>
              </div>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </Button>
            <div className="mt-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Available Balance</p>
                <p className="text-xl font-medium">₹1,25,000</p>
              </div>
              <Button className="bg-[#0071e3] hover:bg-[#0077ED]">Deposit Funds</Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search & Trade */}
      <div className="mt-6 px-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search stocks, ETFs, mutual funds..." className="border-[#e5e5e7] pl-10" />
        </div>

        <Tabs defaultValue="stocks" className="mt-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="stocks">Stocks</TabsTrigger>
            <TabsTrigger value="etfs">ETFs</TabsTrigger>
            <TabsTrigger value="mutual">Mutual Funds</TabsTrigger>
            <TabsTrigger value="crypto">Crypto</TabsTrigger>
          </TabsList>
          <TabsContent value="stocks" className="mt-4 space-y-4">
            {[
              {
                symbol: "RELIANCE",
                name: "Reliance Industries",
                price: "₹2,456.75",
                change: "+1.2%",
                positive: true,
              },
              {
                symbol: "TCS",
                name: "Tata Consultancy Services",
                price: "₹3,567.20",
                change: "-0.5%",
                positive: false,
              },
              {
                symbol: "HDFCBANK",
                name: "HDFC Bank Ltd.",
                price: "₹1,678.90",
                change: "+0.8%",
                positive: true,
              },
            ].map((stock, i) => (
              <Card key={i} className="border-[#e5e5e7]">
                <CardContent className="flex items-center justify-between p-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{stock.symbol}</p>
                      <div
                        className={`flex items-center rounded-full px-2 py-0.5 text-xs ${
                          stock.positive ? "bg-[#30d158]/10 text-[#30d158]" : "bg-[#ff453a]/10 text-[#ff453a]"
                        }`}
                      >
                        {stock.change}
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{stock.name}</p>
                    <p className="mt-1 text-sm font-medium">{stock.price}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 border-[#0071e3] text-xs text-[#0071e3] hover:bg-[#0071e3]/10"
                    >
                      Buy
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 border-[#ff453a] text-xs text-[#ff453a] hover:bg-[#ff453a]/10"
                    >
                      Sell
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          <TabsContent value="etfs">ETFs content will appear here</TabsContent>
          <TabsContent value="mutual">Mutual Funds content will appear here</TabsContent>
          <TabsContent value="crypto">Crypto content will appear here</TabsContent>
        </Tabs>
      </div>

      {/* Market Overview */}
      <div className="mt-6 px-6">
        <h2 className="mb-4 text-lg font-medium">Market Overview</h2>
        <Card className="border-[#e5e5e7]">
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-[#f5f5f7] p-3">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-[#30d158]" />
                  <p className="text-sm font-medium">NIFTY 50</p>
                </div>
                <p className="mt-1 text-lg font-medium">22,456.75</p>
                <p className="text-xs text-[#30d158]">+235.60 (1.05%)</p>
              </div>
              <div className="rounded-lg bg-[#f5f5f7] p-3">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-[#30d158]" />
                  <p className="text-sm font-medium">SENSEX</p>
                </div>
                <p className="mt-1 text-lg font-medium">73,890.45</p>
                <p className="text-xs text-[#30d158]">+780.25 (1.07%)</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders */}
      <div className="mt-6 px-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-medium">Recent Orders</h2>
          <Button variant="ghost" className="h-8 text-xs text-[#0071e3]">
            See All
          </Button>
        </div>
        <div className="space-y-4">
          {[
            {
              symbol: "RELIANCE",
              type: "Buy",
              quantity: "10",
              price: "₹2,450.00",
              status: "Executed",
              date: "Today, 10:45 AM",
            },
            {
              symbol: "INFY",
              type: "Sell",
              quantity: "15",
              price: "₹1,560.75",
              status: "Executed",
              date: "Yesterday, 3:20 PM",
            },
            {
              symbol: "HDFCBANK",
              type: "Buy",
              quantity: "5",
              price: "₹1,675.50",
              status: "Pending",
              date: "Today, 11:30 AM",
            },
          ].map((order, i) => (
            <div key={i} className="flex items-center justify-between rounded-xl border border-[#e5e5e7] p-3">
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full ${
                    order.type === "Buy" ? "bg-[#30d158]/10" : "bg-[#ff453a]/10"
                  }`}
                >
                  <ArrowDownUp className={`h-5 w-5 ${order.type === "Buy" ? "text-[#30d158]" : "text-[#ff453a]"}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{order.symbol}</p>
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs ${
                        order.type === "Buy" ? "bg-[#30d158]/10 text-[#30d158]" : "bg-[#ff453a]/10 text-[#ff453a]"
                      }`}
                    >
                      {order.type}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {order.quantity} shares at {order.price}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className={`text-xs ${order.status === "Executed" ? "text-[#30d158]" : "text-[#ff9f0a]"}`}>
                  {order.status}
                </p>
                <p className="text-xs text-muted-foreground">{order.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
