import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function IntakeForm() {
  return (
    <main className="min-h-screen pb-20">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-[#e5e5e7] bg-white/80 backdrop-blur-md">
        <div className="flex h-14 items-center px-6">
          <Link href="/" className="flex items-center text-[#0071e3]">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Link>
          <h1 className="mx-auto text-lg font-semibold">Financial Profile</h1>
        </div>
      </header>

      <div className="p-6">
        <Card className="border-[#e5e5e7]">
          <CardHeader>
            <CardTitle>Tell us about yourself</CardTitle>
            <CardDescription>This information helps us create a personalized financial plan for you.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input id="age" type="number" placeholder="35" className="border-[#e5e5e7]" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="marital-status">Marital Status</Label>
                  <Select>
                    <SelectTrigger className="border-[#e5e5e7]">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single">Single</SelectItem>
                      <SelectItem value="married">Married</SelectItem>
                      <SelectItem value="divorced">Divorced</SelectItem>
                      <SelectItem value="widowed">Widowed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="income">Annual Income (₹)</Label>
                  <Input id="income" type="number" placeholder="1,200,000" className="border-[#e5e5e7]" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expenses">Monthly Expenses (₹)</Label>
                  <Input id="expenses" type="number" placeholder="50,000" className="border-[#e5e5e7]" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dependents">Number of Dependents</Label>
                  <Input id="dependents" type="number" placeholder="2" className="border-[#e5e5e7]" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="home-value">Home Value (₹)</Label>
                  <Input id="home-value" type="number" placeholder="10,000,000" className="border-[#e5e5e7]" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="mortgage">Mortgage Balance (₹)</Label>
                  <Input id="mortgage" type="number" placeholder="7,500,000" className="border-[#e5e5e7]" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="savings">Savings (₹)</Label>
                  <Input id="savings" type="number" placeholder="500,000" className="border-[#e5e5e7]" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="retirement">Retirement Balance (₹)</Label>
                  <Input id="retirement" type="number" placeholder="2,000,000" className="border-[#e5e5e7]" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="debt">Total Debt (₹)</Label>
                  <Input id="debt" type="number" placeholder="300,000" className="border-[#e5e5e7]" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="retirement-age">Desired Retirement Age</Label>
                  <Input id="retirement-age" type="number" placeholder="60" className="border-[#e5e5e7]" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="life-expectancy">Life Expectancy</Label>
                  <Input id="life-expectancy" type="number" placeholder="85" className="border-[#e5e5e7]" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="concerns">Any concerns or questions?</Label>
                <Textarea
                  id="concerns"
                  placeholder="Tell us about your financial concerns or specific questions..."
                  className="min-h-24 border-[#e5e5e7]"
                />
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Link href="/">
                <Button variant="outline" className="border-[#e5e5e7]">
                  <ArrowLeft className="mr-2 h-4 w-4" /> Back to Start
                </Button>
              </Link>
              <div className="space-x-3">
                <Link href="/results">
                  <Button variant="outline" className="border-[#0071e3] text-[#0071e3] hover:bg-[#0071e3]/10">
                    Skip to Results
                  </Button>
                </Link>
                <Link href="/chat/1">
                  <Button className="bg-[#0071e3] hover:bg-[#0077ED]">
                    Submit <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
