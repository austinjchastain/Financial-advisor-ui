import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-[#e5e5e7] bg-white/80 backdrop-blur-md">
        <div className="flex h-14 items-center justify-between px-6">
          <h1 className="text-lg font-semibold">AI Financial Planner</h1>
          <div className="flex items-center gap-4">
            <Link href="/waitlist" className="text-sm text-[#0071e3]">
              Waitlist
            </Link>
            <Link href="/feedback" className="text-sm text-[#0071e3]">
              Feedback
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center">
        <div className="mb-8 flex h-24 w-24 items-center justify-center rounded-full bg-[#0071e3]">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="48"
            height="48"
            viewBox="0 0 24 24"
            fill="none"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M12 6v6l4 2" />
            <circle cx="12" cy="12" r="10" />
          </svg>
        </div>
        <h2 className="mb-4 text-3xl font-bold tracking-tight">Plan Your Financial Future</h2>
        <p className="mb-8 max-w-md text-center text-muted-foreground">
          Get personalized financial advice powered by AI. Answer a few questions and receive a comprehensive plan
          tailored to your goals.
        </p>
        <Link href="/intake">
          <Button className="bg-[#0071e3] px-8 py-6 text-base hover:bg-[#0077ED]">
            Get Started <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </Link>
      </div>
    </main>
  )
}
