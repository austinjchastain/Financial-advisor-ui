import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowUpRight, Award, BadgeCheck, Briefcase, LineChart, PiggyBank, Shield } from "lucide-react"

export default function Investments() {
  return (
    <main className="min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <div>
          <h1 className="text-xl font-medium">Investments</h1>
          <p className="text-sm text-muted-foreground">Your portfolio performance</p>
        </div>
        <Avatar>
          <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Kumar" />
          <AvatarFallback>KM</AvatarFallback>
        </Avatar>
      </div>

      {/* Portfolio Summary */}
      <div className="px-4">
        <Card className="overflow-hidden border-none bg-gradient-to-br from-[#f5f5f7] to-white shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Portfolio Performance</CardTitle>
            <CardDescription>Overall growth since inception</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-baseline gap-2">
                  <p className="text-3xl font-semibold">+75.2%</p>
                  <p className="text-sm text-[#30d158]">+2.3% today</p>
                </div>
                <p className="text-sm text-muted-foreground">Total value: ₹12,45,600</p>
              </div>
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#f5f5f7]">
                <LineChart className="h-8 w-8 text-[#0071e3]" />
              </div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2">
              <Button variant="outline" className="h-auto border-[#e5e5e7] p-2 text-xs hover:bg-[#f5f5f7]">
                1D
              </Button>
              <Button variant="outline" className="h-auto border-[#e5e5e7] p-2 text-xs hover:bg-[#f5f5f7]">
                1W
              </Button>
              <Button
                variant="outline"
                className="h-auto border-[#0071e3] bg-[#0071e3]/10 p-2 text-xs text-[#0071e3] hover:bg-[#0071e3]/20"
              >
                1M
              </Button>
              <Button variant="outline" className="h-auto border-[#e5e5e7] p-2 text-xs hover:bg-[#f5f5f7]">
                3M
              </Button>
              <Button variant="outline" className="h-auto border-[#e5e5e7] p-2 text-xs hover:bg-[#f5f5f7]">
                1Y
              </Button>
              <Button variant="outline" className="h-auto border-[#e5e5e7] p-2 text-xs hover:bg-[#f5f5f7]">
                All
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Investment Options */}
      <div className="mt-6 px-6">
        <h2 className="mb-4 text-lg font-medium">Investment Goals</h2>
        <div className="space-y-4">
          {[
            {
              icon: Briefcase,
              name: "Invest for your Future",
              amount: "₹8,25,000",
              percentage: 66.2,
              return: "+12.5%",
            },
            {
              icon: Shield,
              name: "Safe yourself",
              amount: "₹2,50,600",
              percentage: 20.1,
              return: "+5.2%",
            },
            {
              icon: PiggyBank,
              name: "Retirement Fund",
              amount: "₹1,70,000",
              percentage: 13.7,
              return: "+8.7%",
            },
          ].map((investment, i) => (
            <Card key={i} className="border-[#e5e5e7]">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#f5f5f7]">
                      <investment.icon className="h-5 w-5 text-[#1d1d1f]" />
                    </div>
                    <div>
                      <p className="font-medium">{investment.name}</p>
                      <p className="text-xs text-muted-foreground">{investment.percentage}% of portfolio</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{investment.amount}</p>
                    <p className="text-xs text-[#30d158]">{investment.return}</p>
                  </div>
                </div>
                <Progress
                  value={investment.percentage}
                  className="mt-3 h-1.5"
                  indicatorClassName={i === 0 ? "bg-[#0071e3]" : i === 1 ? "bg-[#5e5ce6]" : "bg-[#30d158]"}
                />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="mt-6 px-6">
        <h2 className="mb-4 text-lg font-medium">Your Achievements</h2>
        <Card className="border-[#e5e5e7]">
          <CardContent className="p-4">
            <div className="grid grid-cols-3 gap-4">
              {[
                { icon: BadgeCheck, name: "Smart Investor", unlocked: true },
                { icon: Award, name: "Diversification Pro", unlocked: true },
                { icon: Shield, name: "Risk Manager", unlocked: false },
              ].map((achievement, i) => (
                <div key={i} className="flex flex-col items-center text-center">
                  <div
                    className={`flex h-14 w-14 items-center justify-center rounded-full ${
                      achievement.unlocked ? "bg-[#0071e3]" : "bg-[#e5e5e7]"
                    }`}
                  >
                    <achievement.icon className={`h-7 w-7 ${achievement.unlocked ? "text-white" : "text-[#8e8e93]"}`} />
                  </div>
                  <p className="mt-2 text-xs font-medium">{achievement.name}</p>
                  <p className="text-xs text-muted-foreground">{achievement.unlocked ? "Unlocked" : "Locked"}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommended Actions */}
      <div className="mt-6 px-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-medium">Recommended Actions</h2>
          <Button variant="ghost" className="h-8 text-xs text-[#0071e3]">
            See All
          </Button>
        </div>
        <div className="space-y-4">
          {[
            {
              title: "Rebalance Portfolio",
              description: "Your portfolio is overweight in tech stocks",
              action: "Review",
            },
            {
              title: "Tax-Loss Harvesting",
              description: "Potential tax savings opportunity",
              action: "Analyze",
            },
            {
              title: "Increase Contributions",
              description: "Boost your retirement savings",
              action: "Adjust",
            },
          ].map((recommendation, i) => (
            <div key={i} className="flex items-center justify-between rounded-xl border border-[#e5e5e7] p-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#f5f5f7]">
                  <ArrowUpRight className="h-5 w-5 text-[#0071e3]" />
                </div>
                <div>
                  <p className="font-medium">{recommendation.title}</p>
                  <p className="text-xs text-muted-foreground">{recommendation.description}</p>
                </div>
              </div>
              <Button variant="outline" className="h-8 border-[#0071e3] text-xs text-[#0071e3] hover:bg-[#0071e3]/10">
                {recommendation.action}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
